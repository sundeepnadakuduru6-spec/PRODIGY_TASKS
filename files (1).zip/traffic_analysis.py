"""
Prodigy InfoTech — Data Science Internship | Task 5
=====================================================
Traffic Accident Data Analysis & Visualization
Dataset: US-Accidents (Kaggle — Sobhan Moosavi)
         kaggle.com/datasets/sobhanmoosavi/us-accidents

Author : Sam | MSc Data Science
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap, Normalize
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

OUT = "/mnt/user-data/outputs/"

# ── Global theme ─────────────────────────────────────────────────────────────
BG      = "#0D1117"
PANEL   = "#161B22"
ACCENT  = "#58A6FF"
RED     = "#FF4444"
ORANGE  = "#FF8C00"
YELLOW  = "#FFD700"
GREEN   = "#3FB950"
PURPLE  = "#8B5CF6"
GRAY    = "#8B949E"

plt.rcParams.update({
    "figure.dpi": 150,
    "font.family": "DejaVu Sans",
    "text.color": "white",
    "axes.labelcolor": "white",
    "xtick.color": "white",
    "ytick.color": "white",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

SEV_COLORS = {1: GREEN, 2: YELLOW, 3: ORANGE, 4: RED}
SEV_LABELS = {1: "S1 Minor", 2: "S2 Moderate", 3: "S3 Serious", 4: "S4 Fatal"}


# ════════════════════════════════════════════════════════════════════════════
# 1 ▌ DATA GENERATION / LOADING
# ════════════════════════════════════════════════════════════════════════════

US_STATES = {
    "CA": (36.7, -119.4, 0.16), "TX": (31.0, -100.0, 0.13),
    "FL": (27.7,  -81.6, 0.10), "NY": (42.9,  -75.5, 0.07),
    "PA": (40.9,  -77.8, 0.06), "OH": (40.3,  -82.8, 0.05),
    "NC": (35.6,  -79.4, 0.05), "VA": (37.4,  -79.1, 0.04),
    "GA": (32.8,  -83.2, 0.04), "IL": (40.0,  -89.2, 0.04),
    "MI": (44.3,  -85.6, 0.03), "AZ": (33.7, -111.7, 0.03),
    "WA": (47.4, -120.6, 0.03), "CO": (39.1, -105.4, 0.02),
    "NJ": (40.2,  -74.7, 0.02), "MN": (46.4,  -93.1, 0.02),
    "TN": (35.9,  -86.3, 0.02), "MO": (38.5,  -92.5, 0.02),
    "MD": (39.0,  -76.8, 0.01), "IN": (39.8,  -86.1, 0.01),
}

WEATHER_CONDITIONS = [
    ("Clear",             0.28, 1.0),
    ("Overcast",          0.14, 1.3),
    ("Light Rain",        0.12, 1.8),
    ("Mostly Cloudy",     0.10, 1.2),
    ("Partly Cloudy",     0.09, 1.1),
    ("Heavy Rain",        0.06, 2.5),
    ("Light Snow",        0.05, 2.2),
    ("Fog",               0.04, 3.0),
    ("Thunderstorm",      0.04, 3.5),
    ("Heavy Snow",        0.03, 3.8),
    ("Haze",              0.02, 1.7),
    ("Blowing Snow",      0.01, 4.0),
    ("Ice Pellets",       0.01, 4.2),
    ("Freezing Rain",     0.01, 4.5),
]

ROAD_FEATURES = [
    "Amenity","Bump","Crossing","Junction","No_Exit",
    "Railway","Roundabout","Station","Stop","Traffic_Signal","Turning_Loop",
]


def generate_synthetic(n: int = 30_000) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    print(f"⚠  Kaggle CSV not found — generating {n:,} synthetic records …")

    # ── Timestamps ───────────────────────────────────────────────────────────
    start_ts = pd.Timestamp("2016-01-01")
    end_ts   = pd.Timestamp("2023-12-31")
    days_range = (end_ts - start_ts).days

    rand_days  = rng.integers(0, days_range, n)
    hour_p = np.array([
        0.012,0.008,0.006,0.005,0.008,0.018,
        0.040,0.065,0.075,0.055,0.048,0.052,
        0.055,0.050,0.048,0.050,0.058,0.068,
        0.062,0.055,0.042,0.032,0.022,0.016,
    ])
    hour_p /= hour_p.sum()
    rand_hours = rng.choice(np.arange(24), size=n, p=hour_p)
    rand_mins  = rng.integers(0, 60, n)
    start_time = [
        start_ts + pd.Timedelta(days=int(d), hours=int(h), minutes=int(m))
        for d, h, m in zip(rand_days, rand_hours, rand_mins)
    ]
    start_time = pd.DatetimeIndex(start_time)

    # ── States & Coordinates ─────────────────────────────────────────────────
    state_names = list(US_STATES.keys())
    state_probs = [US_STATES[s][2] for s in state_names]
    state_probs = np.array(state_probs) / sum(state_probs)
    state_idx   = rng.choice(len(state_names), n, p=state_probs)
    states      = [state_names[i] for i in state_idx]
    lats  = [US_STATES[s][0] + rng.normal(0, 1.2) for s in states]
    lngs  = [US_STATES[s][1] + rng.normal(0, 1.5) for s in states]

    # ── Weather ──────────────────────────────────────────────────────────────
    w_names  = [w[0] for w in WEATHER_CONDITIONS]
    w_probs  = np.array([w[1] for w in WEATHER_CONDITIONS])
    w_probs /= w_probs.sum()
    weather_idx = rng.choice(len(w_names), n, p=w_probs)
    weather     = [w_names[i] for i in weather_idx]

    # ── Continuous weather vars ───────────────────────────────────────────────
    temp_f       = rng.normal(60, 20, n).clip(-20, 120)
    wind_chill   = temp_f - rng.uniform(0, 10, n)
    humidity     = rng.uniform(20, 100, n)
    visibility   = np.where(
        np.isin(weather, ["Fog","Heavy Rain","Blowing Snow","Ice Pellets"]),
        rng.uniform(0.1, 2, n),
        rng.uniform(5, 10, n),
    )
    wind_speed   = rng.exponential(8, n).clip(0, 70)
    precipitation= np.where(
        np.isin(weather, ["Light Rain","Heavy Rain","Light Snow","Heavy Snow",
                           "Thunderstorm","Freezing Rain","Ice Pellets"]),
        rng.exponential(0.05, n).clip(0, 2),
        np.zeros(n),
    )

    # ── Severity (influenced by weather severity factor) ─────────────────────
    w_sev = np.array([WEATHER_CONDITIONS[i][2] for i in weather_idx])
    hour  = start_time.hour
    # night hours → higher severity
    night_factor = np.where((hour >= 22) | (hour <= 4), 1.4, 1.0)
    # low visibility → higher severity
    vis_factor = np.where(visibility < 2, 1.5, 1.0)
    sev_logit = w_sev * night_factor * vis_factor * rng.uniform(0.7, 1.3, n)
    sev_probs = np.stack([
        np.clip(0.10 / sev_logit, 0.02, 0.40),
        np.clip(0.55 / sev_logit, 0.20, 0.75),
        np.clip(0.25 * sev_logit, 0.05, 0.50),
        np.clip(0.10 * sev_logit, 0.01, 0.30),
    ], axis=1)
    sev_probs /= sev_probs.sum(axis=1, keepdims=True)
    severity = np.array([rng.choice([1,2,3,4], p=p) for p in sev_probs])

    # ── Road features ────────────────────────────────────────────────────────
    feat_probs = [0.05,0.03,0.12,0.15,0.04,0.03,0.02,0.06,0.10,0.18,0.01]
    road_feats = {
        f: rng.random(n) < feat_probs[i]
        for i, f in enumerate(ROAD_FEATURES)
    }

    # ── Day / Night ──────────────────────────────────────────────────────────
    sunrise_sunset = np.where((hour >= 7) & (hour < 19), "Day", "Night")
    day_of_week    = start_time.day_name()
    month          = start_time.month

    df = pd.DataFrame({
        "ID":                [f"A-{i:07d}" for i in range(n)],
        "Severity":          severity,
        "Start_Time":        start_time,
        "Start_Lat":         lats,
        "Start_Lng":         lngs,
        "State":             states,
        "Temperature(F)":    temp_f,
        "Wind_Chill(F)":     wind_chill,
        "Humidity(%)":       humidity,
        "Visibility(mi)":    visibility,
        "Wind_Speed(mph)":   wind_speed,
        "Precipitation(in)": precipitation,
        "Weather_Condition": weather,
        "Sunrise_Sunset":    sunrise_sunset,
        "Hour":              hour,
        "Day_of_Week":       day_of_week,
        "Month":             month,
        **road_feats,
    })

    print(f"✓ Generated {n:,} accident records across {len(US_STATES)} states.")
    return df


def load_or_generate() -> pd.DataFrame:
    for path in ["US_Accidents_March23.csv", "US_Accidents.csv",
                 "us_accidents.csv", "accidents.csv"]:
        try:
            df = pd.read_csv(path, parse_dates=["Start_Time"])
            df["Hour"]        = df["Start_Time"].dt.hour
            df["Day_of_Week"] = df["Start_Time"].dt.day_name()
            df["Month"]       = df["Start_Time"].dt.month
            # ensure road feature cols exist
            for f in ROAD_FEATURES:
                if f not in df.columns:
                    df[f] = False
            print(f"✓ Loaded {path}  ({len(df):,} rows)")
            return df.sample(min(len(df), 30_000), random_state=42)
        except FileNotFoundError:
            pass
    return generate_synthetic()


# ════════════════════════════════════════════════════════════════════════════
# HELPER
# ════════════════════════════════════════════════════════════════════════════
def dark_ax(ax):
    ax.set_facecolor(PANEL)
    for spine in ax.spines.values():
        spine.set_edgecolor("#30363D")
    return ax


# ════════════════════════════════════════════════════════════════════════════
# 2 ▌ FIG 1 — SEVERITY DISTRIBUTION
# ════════════════════════════════════════════════════════════════════════════
def fig1_severity(df):
    sev_counts = df["Severity"].value_counts().sort_index()
    total = len(df)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.patch.set_facecolor(BG)

    # ── Donut ───────────────────────────────────────────────────────────────
    colors = [SEV_COLORS[s] for s in sev_counts.index]
    wedges, texts, autos = axes[0].pie(
        sev_counts.values, labels=[SEV_LABELS[s] for s in sev_counts.index],
        colors=colors, autopct="%1.1f%%", startangle=90,
        wedgeprops=dict(width=0.58, edgecolor=BG, linewidth=2.5),
        textprops=dict(color="white", fontsize=11),
    )
    for at in autos:
        at.set_fontsize(10); at.set_fontweight("bold"); at.set_color("white")
    axes[0].set_facecolor(BG)
    axes[0].set_title("Accident Severity Distribution", color="white",
                      fontsize=14, fontweight="bold", pad=18)

    # ── Bar with gradient ────────────────────────────────────────────────────
    dark_ax(axes[1])
    bars = axes[1].bar(
        [SEV_LABELS[s] for s in sev_counts.index],
        sev_counts.values,
        color=colors, edgecolor=BG, linewidth=1.5, width=0.6,
    )
    for bar, val in zip(bars, sev_counts.values):
        axes[1].text(
            bar.get_x() + bar.get_width()/2, bar.get_height() + 30,
            f"{val:,}\n({val/total*100:.1f}%)",
            ha="center", va="bottom", color="white",
            fontsize=10, fontweight="bold",
        )
    axes[1].set_title("Count by Severity Level", color="white",
                      fontsize=14, fontweight="bold")
    axes[1].set_ylabel("Number of Accidents", color="white")
    axes[1].tick_params(labelsize=10)
    axes[1].set_ylim(0, sev_counts.max() * 1.18)

    plt.suptitle("🚨  US Traffic Accidents — Severity Analysis",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig1_severity_distribution.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig1_severity_distribution.png")


# ════════════════════════════════════════════════════════════════════════════
# 3 ▌ FIG 2 — TIME PATTERNS (hour × day-of-week heatmap + hourly line)
# ════════════════════════════════════════════════════════════════════════════
def fig2_time_patterns(df):
    day_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.patch.set_facecolor(BG)

    # ── Hour × Weekday heatmap ───────────────────────────────────────────────
    pivot = df.groupby(["Day_of_Week", "Hour"]).size().unstack(fill_value=0)
    pivot = pivot.reindex([d for d in day_order if d in pivot.index])

    dark_ax(axes[0])
    cmap = LinearSegmentedColormap.from_list("hot", [PANEL, YELLOW, ORANGE, RED])
    sns.heatmap(
        pivot, ax=axes[0], cmap=cmap,
        linewidths=0.3, linecolor="#1C2128",
        cbar_kws={"label": "Accident Count", "shrink": 0.85},
    )
    axes[0].set_title("Accident Frequency — Day × Hour Heatmap",
                      color="white", fontsize=13, fontweight="bold", pad=12)
    axes[0].set_xlabel("Hour of Day", color="white")
    axes[0].set_ylabel("Day of Week", color="white")
    axes[0].tick_params(labelsize=8)
    axes[0].figure.axes[-1].tick_params(colors="white", labelsize=8)
    axes[0].figure.axes[-1].yaxis.label.set_color("white")

    # ── Hourly trend by severity ─────────────────────────────────────────────
    dark_ax(axes[1])
    for sev in [1, 2, 3, 4]:
        sub = df[df["Severity"] == sev]
        hourly = sub.groupby("Hour").size()
        axes[1].plot(
            hourly.index, hourly.values,
            color=SEV_COLORS[sev], label=SEV_LABELS[sev],
            linewidth=2.2, marker="o", markersize=4, alpha=0.85,
        )
    # shade rush hours
    for rh_start, rh_end in [(6.5, 9.5), (16, 19)]:
        axes[1].axvspan(rh_start, rh_end, alpha=0.08, color=YELLOW)
    axes[1].text(7.5, axes[1].get_ylim()[1] * 0.92, "Rush\nHour",
                 ha="center", color=YELLOW, fontsize=8, alpha=0.7)
    axes[1].text(17.2, axes[1].get_ylim()[1] * 0.92, "Rush\nHour",
                 ha="center", color=YELLOW, fontsize=8, alpha=0.7)
    axes[1].set_title("Hourly Accident Frequency by Severity",
                      color="white", fontsize=13, fontweight="bold")
    axes[1].set_xlabel("Hour of Day (0–23)", color="white")
    axes[1].set_ylabel("Accident Count", color="white")
    axes[1].set_xticks(range(0, 24, 2))
    leg = axes[1].legend(fontsize=9, framealpha=0.15, labelcolor="white")
    leg.get_frame().set_edgecolor("#444")

    plt.suptitle("🕐  Time-Based Accident Patterns",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig2_time_patterns.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig2_time_patterns.png")


# ════════════════════════════════════════════════════════════════════════════
# 4 ▌ FIG 3 — WEATHER CONDITIONS
# ════════════════════════════════════════════════════════════════════════════
def fig3_weather(df):
    top_w = df["Weather_Condition"].value_counts().head(12)

    # avg severity per weather
    sev_by_weather = (
        df.groupby("Weather_Condition")["Severity"].mean()
        .reindex(top_w.index)
    )

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    fig.patch.set_facecolor(BG)

    # ── Count bar ────────────────────────────────────────────────────────────
    dark_ax(axes[0])
    cmap_w = LinearSegmentedColormap.from_list("wb", [ACCENT, PURPLE], N=12)
    colors_w = [cmap_w(i/12) for i in range(len(top_w))]
    bars = axes[0].barh(
        top_w.index[::-1], top_w.values[::-1],
        color=colors_w[::-1], edgecolor=BG, linewidth=0.8,
    )
    for bar, val in zip(bars, top_w.values[::-1]):
        axes[0].text(
            bar.get_width() + 30, bar.get_y() + bar.get_height()/2,
            f"{val:,}", va="center", color="white", fontsize=9,
        )
    axes[0].set_title("Accidents by Weather Condition (Top 12)",
                      color="white", fontsize=13, fontweight="bold")
    axes[0].set_xlabel("Number of Accidents", color="white")

    # ── Avg severity bubble plot ─────────────────────────────────────────────
    dark_ax(axes[1])
    sev_sorted = sev_by_weather.sort_values(ascending=False)
    sev_norm = (sev_sorted - 1) / 3   # normalize 1→4 to 0→1
    bubble_colors = [
        LinearSegmentedColormap.from_list("sev", [GREEN, RED])(v)
        for v in sev_norm
    ]
    axes[1].scatter(
        sev_sorted.values,
        range(len(sev_sorted)),
        s=[top_w.get(w, 1) / 15 for w in sev_sorted.index],
        c=bubble_colors, edgecolors="white", linewidth=0.5, alpha=0.9, zorder=5,
    )
    axes[1].set_yticks(range(len(sev_sorted)))
    axes[1].set_yticklabels(sev_sorted.index, fontsize=9)
    axes[1].axvline(2.0, color=YELLOW, linewidth=1, linestyle="--", alpha=0.5)
    axes[1].set_xlabel("Average Severity Score (1=Minor → 4=Fatal)", color="white")
    axes[1].set_title("Avg Severity by Weather\n(bubble size = accident count)",
                      color="white", fontsize=13, fontweight="bold")
    axes[1].set_xlim(1.0, 4.2)

    plt.suptitle("🌦️  Weather Conditions & Accident Severity",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig3_weather_analysis.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig3_weather_analysis.png")


# ════════════════════════════════════════════════════════════════════════════
# 5 ▌ FIG 4 — ROAD CONDITIONS (Visibility, Temperature, Humidity)
# ════════════════════════════════════════════════════════════════════════════
def fig4_road_conditions(df):
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    fig.patch.set_facecolor(BG)

    configs = [
        ("Visibility(mi)",    "Visibility (miles)",    ACCENT,  (0, 10)),
        ("Temperature(F)",    "Temperature (°F)",       ORANGE,  (-20, 115)),
        ("Humidity(%)",       "Humidity (%)",           PURPLE,  (0, 100)),
    ]

    for ax, (col, xlabel, color, xlim) in zip(axes, configs):
        dark_ax(ax)
        if col not in df.columns:
            ax.text(0.5, 0.5, f"'{col}'\nnot in dataset",
                    ha="center", va="center", color=GRAY,
                    transform=ax.transAxes, fontsize=11)
            continue

        for sev in [1, 2, 3, 4]:
            data = df[df["Severity"] == sev][col].dropna()
            data = data[(data >= xlim[0]) & (data <= xlim[1])]
            ax.hist(
                data, bins=40, alpha=0.5,
                color=SEV_COLORS[sev], label=SEV_LABELS[sev],
                density=True, edgecolor="none",
            )
        ax.set_title(f"Distribution of {xlabel}\nby Severity",
                     color="white", fontsize=12, fontweight="bold")
        ax.set_xlabel(xlabel, color="white")
        ax.set_ylabel("Density", color="white")
        ax.set_xlim(xlim)
        leg = ax.legend(fontsize=8, framealpha=0.15, labelcolor="white")
        leg.get_frame().set_edgecolor("#444")

    plt.suptitle("🛣️  Road & Environmental Conditions vs Accident Severity",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig4_road_conditions.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig4_road_conditions.png")


# ════════════════════════════════════════════════════════════════════════════
# 6 ▌ FIG 5 — ROAD FEATURES / CONTRIBUTING FACTORS
# ════════════════════════════════════════════════════════════════════════════
def fig5_road_features(df):
    present_feats = [f for f in ROAD_FEATURES if f in df.columns]
    feat_counts = {
        f: df[df[f] == True].shape[0]
        for f in present_feats
    }
    feat_sev = {
        f: df[df[f] == True]["Severity"].mean()
        for f in present_feats
        if df[df[f] == True].shape[0] > 10
    }
    feat_df = pd.DataFrame({
        "Feature": list(feat_sev.keys()),
        "Count":   [feat_counts[f] for f in feat_sev.keys()],
        "AvgSev":  list(feat_sev.values()),
    }).sort_values("Count", ascending=False)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.patch.set_facecolor(BG)

    # ── Accident count per feature ───────────────────────────────────────────
    dark_ax(axes[0])
    cmap_f = LinearSegmentedColormap.from_list("fc", [ACCENT, PURPLE])
    colors_f = [cmap_f(i / len(feat_df)) for i in range(len(feat_df))]
    bars = axes[0].bar(
        feat_df["Feature"], feat_df["Count"],
        color=colors_f, edgecolor=BG, linewidth=0.8, width=0.6,
    )
    for bar, val in zip(bars, feat_df["Count"]):
        axes[0].text(
            bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
            f"{val:,}", ha="center", va="bottom", color="white", fontsize=8,
        )
    axes[0].set_title("Accidents by Road Feature Present",
                      color="white", fontsize=13, fontweight="bold")
    axes[0].set_ylabel("Number of Accidents", color="white")
    axes[0].tick_params(axis="x", rotation=35, labelsize=8)

    # ── Avg severity per feature ─────────────────────────────────────────────
    dark_ax(axes[1])
    feat_sev_sorted = feat_df.sort_values("AvgSev", ascending=True)
    sev_norm = (feat_sev_sorted["AvgSev"] - 1) / 3
    bar_colors = [
        LinearSegmentedColormap.from_list("gs", [GREEN, RED])(v)
        for v in sev_norm
    ]
    hbars = axes[1].barh(
        feat_sev_sorted["Feature"], feat_sev_sorted["AvgSev"],
        color=bar_colors, edgecolor=BG, linewidth=0.8,
    )
    axes[1].axvline(2.0, color=YELLOW, linewidth=1.2, linestyle="--",
                    alpha=0.6, label="Avg Severity = 2")
    for bar, val in zip(hbars, feat_sev_sorted["AvgSev"]):
        axes[1].text(
            val + 0.01, bar.get_y() + bar.get_height()/2,
            f"{val:.2f}", va="center", color="white", fontsize=9,
        )
    axes[1].set_title("Average Severity by Road Feature",
                      color="white", fontsize=13, fontweight="bold")
    axes[1].set_xlabel("Average Severity (1 → 4)", color="white")
    axes[1].set_xlim(1.0, 4.2)
    axes[1].legend(fontsize=9, framealpha=0.15, labelcolor="white")

    plt.suptitle("🚦  Road Features & Contributing Factors",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig5_road_features.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig5_road_features.png")


# ════════════════════════════════════════════════════════════════════════════
# 7 ▌ FIG 6 — STATE-WISE ANALYSIS
# ════════════════════════════════════════════════════════════════════════════
def fig6_state_analysis(df):
    state_vol  = df["State"].value_counts().head(15)
    state_sev  = df.groupby("State")["Severity"].mean().reindex(state_vol.index)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.patch.set_facecolor(BG)

    # ── Top states by volume ─────────────────────────────────────────────────
    dark_ax(axes[0])
    cmap_s = LinearSegmentedColormap.from_list("sv", [ACCENT, RED])
    c_norm = state_vol.values / state_vol.max()
    bars = axes[0].barh(
        state_vol.index[::-1], state_vol.values[::-1],
        color=[cmap_s(v) for v in c_norm[::-1]],
        edgecolor=BG, linewidth=0.8,
    )
    for bar, val in zip(bars, state_vol.values[::-1]):
        axes[0].text(
            bar.get_width() + 15, bar.get_y() + bar.get_height()/2,
            f"{val:,}", va="center", color="white", fontsize=9,
        )
    axes[0].set_title("Top 15 States by Accident Volume",
                      color="white", fontsize=13, fontweight="bold")
    axes[0].set_xlabel("Number of Accidents", color="white")

    # ── Severity vs Volume scatter ────────────────────────────────────────────
    dark_ax(axes[1])
    all_states_vol = df["State"].value_counts()
    all_states_sev = df.groupby("State")["Severity"].mean()
    common = all_states_vol.index.intersection(all_states_sev.index)
    xs = all_states_vol[common].values
    ys = all_states_sev[common].values
    sn = all_states_vol[common].index

    scatter = axes[1].scatter(
        xs, ys, s=80,
        c=ys, cmap=LinearSegmentedColormap.from_list("gs", [GREEN, RED]),
        edgecolors="white", linewidth=0.5, alpha=0.85, zorder=5,
    )
    for x, y, s in zip(xs, ys, sn):
        if x > np.percentile(xs, 75) or y > np.percentile(ys, 75):
            axes[1].annotate(s, (x, y), textcoords="offset points",
                             xytext=(5, 3), fontsize=7, color=GRAY)
    axes[1].axhline(ys.mean(), color=YELLOW, linewidth=1, linestyle="--",
                    alpha=0.6, label=f"Avg severity = {ys.mean():.2f}")
    axes[1].set_xlabel("Accident Volume", color="white")
    axes[1].set_ylabel("Average Severity", color="white")
    axes[1].set_title("Accident Volume vs Avg Severity by State",
                      color="white", fontsize=13, fontweight="bold")
    axes[1].legend(fontsize=9, framealpha=0.15, labelcolor="white")
    plt.colorbar(scatter, ax=axes[1]).ax.tick_params(colors="white")

    plt.suptitle("🗺️  State-Wise Accident Analysis",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig6_state_analysis.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig6_state_analysis.png")


# ════════════════════════════════════════════════════════════════════════════
# 8 ▌ FIG 7 — GEOGRAPHIC ACCIDENT HOTSPOT MAP
# ════════════════════════════════════════════════════════════════════════════
def fig7_hotspot_map(df):
    sub = df.dropna(subset=["Start_Lat", "Start_Lng"]).copy()
    sub = sub[
        (sub["Start_Lat"].between(24, 50)) &
        (sub["Start_Lng"].between(-125, -66))
    ]

    fig, ax = plt.subplots(figsize=(16, 9))
    fig.patch.set_facecolor(BG)
    dark_ax(ax)

    # Density hexbin
    hb = ax.hexbin(
        sub["Start_Lng"], sub["Start_Lat"],
        gridsize=80, mincnt=1,
        cmap=LinearSegmentedColormap.from_list(
            "hotspot", [BG, PANEL, "#8B0000", RED, ORANGE, YELLOW, "white"]),
        alpha=0.9,
    )
    cb = plt.colorbar(hb, ax=ax, pad=0.01, shrink=0.7)
    cb.set_label("Accident Density", color="white", fontsize=10)
    cb.ax.tick_params(colors="white")

    # Overlay severity-4 accidents
    fatal = sub[sub["Severity"] == 4]
    ax.scatter(
        fatal["Start_Lng"], fatal["Start_Lat"],
        c=RED, s=8, alpha=0.4, marker="x", linewidths=0.7,
        label=f"Severity 4 ({len(fatal):,})",
        zorder=5,
    )

    # State label markers
    for state, (lat, lng, _) in US_STATES.items():
        ax.text(lng, lat, state, ha="center", va="center",
                fontsize=6, color="white", alpha=0.5,
                fontfamily="monospace")

    ax.set_title("🗺️  US Accident Hotspot Map (Density + Severity-4 overlay)",
                 color="white", fontsize=15, fontweight="bold", pad=15)
    ax.set_xlabel("Longitude", color="white")
    ax.set_ylabel("Latitude", color="white")
    ax.set_xlim(-130, -60)
    ax.set_ylim(22, 52)
    leg = ax.legend(fontsize=10, framealpha=0.2, labelcolor="white",
                    loc="lower right")
    leg.get_frame().set_edgecolor("#444")

    # Add continental outline via simple border box
    border = mpatches.FancyBboxPatch(
        (-130, 22), 70, 30, boxstyle="round,pad=0",
        fill=False, edgecolor="#444", linewidth=1,
    )

    plt.tight_layout()
    plt.savefig(f"{OUT}fig7_hotspot_map.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig7_hotspot_map.png")


# ════════════════════════════════════════════════════════════════════════════
# 9 ▌ FIG 8 — SEASONAL & MONTHLY PATTERNS
# ════════════════════════════════════════════════════════════════════════════
def fig8_seasonal(df):
    month_map   = {1:"Jan",2:"Feb",3:"Mar",4:"Apr",5:"May",6:"Jun",
                   7:"Jul",8:"Aug",9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
    season_map  = {12:"Winter",1:"Winter",2:"Winter",
                   3:"Spring",4:"Spring",5:"Spring",
                   6:"Summer",7:"Summer",8:"Summer",
                   9:"Autumn",10:"Autumn",11:"Autumn"}
    season_col  = {"Winter":ACCENT,"Spring":GREEN,"Summer":YELLOW,"Autumn":ORANGE}

    df2 = df.copy()
    df2["Month_Name"] = df2["Month"].map(month_map)
    df2["Season"]     = df2["Month"].map(season_map)

    monthly = df2.groupby("Month").size().reindex(range(1,13), fill_value=0)
    seasonal = df2.groupby("Season").size().reindex(
        ["Spring","Summer","Autumn","Winter"], fill_value=0)
    day_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    daily     = df2["Day_of_Week"].value_counts().reindex(day_order, fill_value=0)

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    fig.patch.set_facecolor(BG)

    # Monthly
    dark_ax(axes[0])
    month_colors = [
        season_col[season_map[m]] for m in range(1,13)
    ]
    axes[0].bar([month_map[m] for m in range(1,13)],
                monthly.values, color=month_colors, edgecolor=BG, linewidth=0.8)
    axes[0].set_title("Monthly Accident Count", color="white",
                      fontsize=13, fontweight="bold")
    axes[0].set_ylabel("Accidents", color="white")
    axes[0].tick_params(axis="x", rotation=45, labelsize=8)
    patches = [mpatches.Patch(color=c, label=s) for s, c in season_col.items()]
    axes[0].legend(handles=patches, fontsize=8, framealpha=0.15, labelcolor="white")

    # Seasonal donut
    dark_ax(axes[1])
    seas_colors = [season_col[s] for s in seasonal.index]
    axes[1].pie(
        seasonal.values, labels=seasonal.index, colors=seas_colors,
        autopct="%1.1f%%", startangle=90,
        wedgeprops=dict(width=0.55, edgecolor=BG, linewidth=2),
        textprops=dict(color="white", fontsize=11),
    )
    axes[1].set_title("Accidents by Season", color="white",
                      fontsize=13, fontweight="bold")

    # Day of week
    dark_ax(axes[2])
    day_cols = [YELLOW if d in ["Saturday","Sunday"] else ACCENT for d in daily.index]
    axes[2].bar(daily.index, daily.values, color=day_cols, edgecolor=BG,
                linewidth=0.8, width=0.6)
    axes[2].set_title("Accidents by Day of Week", color="white",
                      fontsize=13, fontweight="bold")
    axes[2].set_ylabel("Accidents", color="white")
    axes[2].tick_params(axis="x", rotation=35, labelsize=8)
    axes[2].text(5, daily.max() * 0.9, "Weekend", color=YELLOW,
                 fontsize=9, ha="center", alpha=0.8)

    plt.suptitle("📅  Seasonal & Calendar Patterns",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig8_seasonal_patterns.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig8_seasonal_patterns.png")


# ════════════════════════════════════════════════════════════════════════════
# 10 ▌ FIG 9 — DAY/NIGHT & MULTI-FACTOR CORRELATION
# ════════════════════════════════════════════════════════════════════════════
def fig9_daynight_and_correlation(df):
    num_cols = ["Severity","Temperature(F)","Humidity(%)",
                "Visibility(mi)","Wind_Speed(mph)","Precipitation(in)"]
    num_cols = [c for c in num_cols if c in df.columns]

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    fig.patch.set_facecolor(BG)

    # ── Day vs Night ─────────────────────────────────────────────────────────
    dark_ax(axes[0])
    dn_sev = df.groupby(["Sunrise_Sunset","Severity"]).size().unstack(fill_value=0)
    dn_pct = dn_sev.div(dn_sev.sum(axis=1), axis=0) * 100
    sev_cols = [SEV_COLORS[s] for s in dn_pct.columns]
    bottoms = np.zeros(len(dn_pct))
    for col, color in zip(dn_pct.columns, sev_cols):
        vals = dn_pct[col].values
        bars = axes[0].bar(dn_pct.index, vals, bottom=bottoms,
                           color=color, label=SEV_LABELS[col],
                           edgecolor=BG, linewidth=0.8, width=0.45)
        for bar, v in zip(bars, vals):
            if v > 5:
                axes[0].text(
                    bar.get_x() + bar.get_width()/2,
                    bar.get_y() + bar.get_height()/2,
                    f"{v:.1f}%", ha="center", va="center",
                    color="white", fontsize=10, fontweight="bold",
                )
        bottoms += vals
    axes[0].set_title("Severity Split: Day vs Night Accidents",
                      color="white", fontsize=13, fontweight="bold")
    axes[0].set_ylabel("Percentage (%)", color="white")
    leg = axes[0].legend(fontsize=9, framealpha=0.15, labelcolor="white",
                         loc="upper right")
    leg.get_frame().set_edgecolor("#444")

    # ── Correlation heatmap ───────────────────────────────────────────────────
    dark_ax(axes[1])
    corr = df[num_cols].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
    sns.heatmap(
        corr, ax=axes[1], annot=True, fmt=".2f",
        cmap=LinearSegmentedColormap.from_list("rb", [RED, PANEL, GREEN]),
        linewidths=0.4, linecolor="#222",
        cbar_kws={"shrink": 0.8},
        annot_kws={"size": 9, "color": "white"},
        vmin=-1, vmax=1,
    )
    axes[1].set_title("Feature Correlation Matrix",
                      color="white", fontsize=13, fontweight="bold", pad=12)
    axes[1].tick_params(labelsize=9, rotation=30)
    axes[1].figure.axes[-1].tick_params(colors="white")

    plt.suptitle("🌙  Day/Night Patterns & Feature Correlations",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig9_daynight_correlation.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig9_daynight_correlation.png")


# ════════════════════════════════════════════════════════════════════════════
# 11 ▌ FIG 10 — EXECUTIVE DASHBOARD
# ════════════════════════════════════════════════════════════════════════════
def fig10_dashboard(df):
    fig = plt.figure(figsize=(18, 10))
    fig.patch.set_facecolor(BG)
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.55, wspace=0.4,
                           height_ratios=[0.6, 1.2, 1.2])

    # ── KPI strip ────────────────────────────────────────────────────────────
    kpi_ax = fig.add_subplot(gs[0, :])
    kpi_ax.set_facecolor(BG); kpi_ax.axis("off")

    total   = len(df)
    sev4_pct = (df["Severity"] == 4).mean() * 100
    night_pct = (df["Sunrise_Sunset"] == "Night").mean() * 100
    peak_hr  = int(df["Hour"].value_counts().idxmax())
    worst_st = df["State"].value_counts().index[0]
    avg_sev  = df["Severity"].mean()

    kpis = [
        ("🚗 Total Accidents",  f"{total:,}",          ACCENT),
        ("⚠️  Severity-4 Rate",  f"{sev4_pct:.1f}%",   RED),
        ("🌙 Night Accidents",  f"{night_pct:.0f}%",   PURPLE),
        ("🕐 Peak Hour",        f"{peak_hr:02d}:00",   YELLOW),
        ("🗺️  Highest-Risk State", worst_st,            ORANGE),
        ("📊 Avg Severity",     f"{avg_sev:.2f} / 4",  GREEN),
    ]
    for i, (label, val, col) in enumerate(kpis):
        x = 0.07 + i * 0.155
        kpi_ax.text(x, 0.80, val, transform=kpi_ax.transAxes,
                    fontsize=20, fontweight="bold", color=col, ha="center")
        kpi_ax.text(x, 0.15, label, transform=kpi_ax.transAxes,
                    fontsize=8.5, color=GRAY, ha="center")

    # ── Hourly line ───────────────────────────────────────────────────────────
    ax1 = fig.add_subplot(gs[1, :2])
    dark_ax(ax1)
    hourly = df.groupby("Hour").size()
    ax1.fill_between(hourly.index, hourly.values, alpha=0.3, color=ACCENT)
    ax1.plot(hourly.index, hourly.values, color=ACCENT, linewidth=2.2, marker="o", ms=4)
    ax1.set_title("Hourly Accident Trend", color="white", fontsize=11, fontweight="bold")
    ax1.set_xlabel("Hour", color="white", fontsize=9)
    ax1.set_ylabel("Count", color="white", fontsize=9)
    ax1.set_xticks(range(0, 24, 3))
    ax1.tick_params(labelsize=8)

    # ── Top weather ───────────────────────────────────────────────────────────
    ax2 = fig.add_subplot(gs[1, 2:])
    dark_ax(ax2)
    tw = df["Weather_Condition"].value_counts().head(6)
    cmap_t = LinearSegmentedColormap.from_list("wp", [ACCENT, PURPLE])
    bars = ax2.barh(tw.index[::-1], tw.values[::-1],
                    color=[cmap_t(i/6) for i in range(6)][::-1],
                    edgecolor=BG)
    for bar, val in zip(bars, tw.values[::-1]):
        ax2.text(bar.get_width() + 5, bar.get_y() + bar.get_height()/2,
                 f"{val:,}", va="center", color="white", fontsize=8)
    ax2.set_title("Top 6 Weather Conditions", color="white",
                  fontsize=11, fontweight="bold")
    ax2.tick_params(labelsize=8)

    # ── Day of week ───────────────────────────────────────────────────────────
    ax3 = fig.add_subplot(gs[2, :2])
    dark_ax(ax3)
    day_order = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    dow_full = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    daily = df["Day_of_Week"].value_counts().reindex(dow_full, fill_value=0)
    dcols = [YELLOW if d in ["Saturday","Sunday"] else ACCENT for d in dow_full]
    ax3.bar(day_order, daily.values, color=dcols, edgecolor=BG, width=0.6)
    ax3.set_title("Accidents by Day of Week", color="white",
                  fontsize=11, fontweight="bold")
    ax3.tick_params(labelsize=9)

    # ── Severity pie ─────────────────────────────────────────────────────────
    ax4 = fig.add_subplot(gs[2, 2:])
    dark_ax(ax4)
    sev_c = df["Severity"].value_counts().sort_index()
    ax4.pie(
        sev_c.values,
        labels=[SEV_LABELS[s] for s in sev_c.index],
        colors=[SEV_COLORS[s] for s in sev_c.index],
        autopct="%1.1f%%", startangle=90,
        wedgeprops=dict(width=0.55, edgecolor=BG, linewidth=2),
        textprops=dict(color="white", fontsize=9),
    )
    ax4.set_title("Severity Breakdown", color="white",
                  fontsize=11, fontweight="bold")

    plt.suptitle("📋  US Traffic Accidents — Executive Dashboard",
                 color="white", fontsize=18, fontweight="bold", y=1.01)
    plt.savefig(f"{OUT}fig10_dashboard.png", dpi=150,
                bbox_inches="tight", facecolor=BG)
    plt.close()
    print("  ✓ fig10_dashboard.png")


# ════════════════════════════════════════════════════════════════════════════
# 12 ▌ SUMMARY
# ════════════════════════════════════════════════════════════════════════════
def print_summary(df):
    print("\n" + "═"*65)
    print("  US TRAFFIC ACCIDENTS — ANALYSIS REPORT")
    print("═"*65)
    print(f"  Records analysed      : {len(df):,}")
    print(f"  States covered        : {df['State'].nunique()}")
    print(f"  Date range            : {df['Start_Time'].min().date()} → {df['Start_Time'].max().date()}")

    print(f"\n  ── Severity Distribution ──")
    for s in [1,2,3,4]:
        cnt = (df["Severity"]==s).sum()
        bar = "█" * int(cnt/len(df)*40)
        print(f"  {SEV_LABELS[s]:<14}: {cnt:>6,}  ({cnt/len(df)*100:5.1f}%)  {bar}")

    print(f"\n  ── Peak Accident Hours ──")
    top_hours = df["Hour"].value_counts().head(5)
    for hr, cnt in top_hours.items():
        print(f"  {hr:02d}:00 — {hr+1:02d}:00  : {cnt:,} accidents")

    print(f"\n  ── Top 5 Dangerous States ──")
    for state, cnt in df["State"].value_counts().head(5).items():
        avg_s = df[df["State"]==state]["Severity"].mean()
        print(f"  {state}  {cnt:>5,} accidents | Avg Severity: {avg_s:.2f}")

    print(f"\n  ── Most Common Weather Conditions ──")
    for w, cnt in df["Weather_Condition"].value_counts().head(5).items():
        avg_s = df[df["Weather_Condition"]==w]["Severity"].mean()
        print(f"  {w:<22}: {cnt:>5,}  | Avg Sev: {avg_s:.2f}")

    night = df["Sunrise_Sunset"].value_counts(normalize=True).get("Night", 0) * 100
    print(f"\n  🌙  Night-time accidents : {night:.1f}% of total")
    print(f"  🕐  Peak accident hour   : {int(df['Hour'].value_counts().idxmax()):02d}:00")
    print(f"  📊  Average severity     : {df['Severity'].mean():.3f}")
    print("═"*65 + "\n")


# ════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import os
    os.makedirs(OUT, exist_ok=True)

    print("\n🚗  Prodigy InfoTech — Task 5 | US Traffic Accident Analysis")
    print("─" * 65)

    df = load_or_generate()
    print_summary(df)

    print("📊  Generating 10 visualizations …\n")
    fig1_severity(df)
    fig2_time_patterns(df)
    fig3_weather(df)
    fig4_road_conditions(df)
    fig5_road_features(df)
    fig6_state_analysis(df)
    fig7_hotspot_map(df)
    fig8_seasonal(df)
    fig9_daynight_and_correlation(df)
    fig10_dashboard(df)

    print(f"\n✅  All outputs saved to {OUT}")

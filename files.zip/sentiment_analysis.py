"""
Prodigy InfoTech - Data Science Internship | Task 4
====================================================
Sentiment Analysis & Visualization of Social Media (Twitter) Data
Dataset: twitter_training.csv + twitter_validation.csv
         (Twitter Entity Sentiment Analysis – Kaggle)

Author : Sam | MSc Data Science
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
import seaborn as sns
from collections import Counter
import re
import warnings
warnings.filterwarnings("ignore")

# ── Optional: WordCloud ──────────────────────────────────────────────────────
try:
    from wordcloud import WordCloud, STOPWORDS
    WC_AVAILABLE = True
except ImportError:
    WC_AVAILABLE = False

# ── Style ────────────────────────────────────────────────────────────────────
plt.rcParams.update({
    "figure.dpi": 150,
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

PALETTE = {
    "Positive":    "#2ECC71",
    "Negative":    "#E74C3C",
    "Neutral":     "#3498DB",
    "Irrelevant":  "#95A5A6",
}

OUT = "/mnt/user-data/outputs/"


# ════════════════════════════════════════════════════════════════════════════
# 1 ▌ LOAD / GENERATE DATASET
# ════════════════════════════════════════════════════════════════════════════
def load_or_generate() -> pd.DataFrame:
    """Try local files; fall back to a richly-structured synthetic dataset."""
    cols = ["tweet_id", "entity", "sentiment", "tweet_content"]

    for path in ["twitter_training.csv", "twitter_validation.csv"]:
        try:
            df = pd.read_csv(path, header=None, names=cols)
            print(f"✓ Loaded {path}  ({len(df):,} rows)")
            return df
        except FileNotFoundError:
            pass

    print("⚠  Dataset files not found — generating synthetic dataset …")

    np.random.seed(42)
    rng = np.random.default_rng(42)

    brands = {
        "Apple":     {"Positive": 0.45, "Negative": 0.25, "Neutral": 0.20, "Irrelevant": 0.10},
        "Google":    {"Positive": 0.50, "Negative": 0.15, "Neutral": 0.25, "Irrelevant": 0.10},
        "Amazon":    {"Positive": 0.40, "Negative": 0.30, "Neutral": 0.20, "Irrelevant": 0.10},
        "Microsoft": {"Positive": 0.42, "Negative": 0.20, "Neutral": 0.28, "Irrelevant": 0.10},
        "Tesla":     {"Positive": 0.35, "Negative": 0.35, "Neutral": 0.20, "Irrelevant": 0.10},
        "Netflix":   {"Positive": 0.48, "Negative": 0.22, "Neutral": 0.20, "Irrelevant": 0.10},
        "Twitter":   {"Positive": 0.30, "Negative": 0.40, "Neutral": 0.20, "Irrelevant": 0.10},
        "Facebook":  {"Positive": 0.28, "Negative": 0.42, "Neutral": 0.20, "Irrelevant": 0.10},
    }

    tweet_templates = {
        "Positive": [
            "I absolutely love {brand}! Best product ever. #amazing",
            "{brand} just made my day with their incredible service!",
            "Wow, {brand}'s new update is fantastic! Super impressed.",
            "Can't imagine life without {brand}. So grateful. ❤️",
            "{brand} customer support is outstanding! Quick & helpful.",
            "Just upgraded to {brand}'s latest and I'm blown away! 🔥",
            "{brand} keeps getting better every year. Loyal customer for life!",
            "The new {brand} feature is exactly what I needed. Thank you!",
        ],
        "Negative": [
            "{brand} just ruined my day. Terrible experience. 😡",
            "Disappointed with {brand} again. When will they improve?",
            "{brand} customer service is the WORST. Never again.",
            "My {brand} device crashed for the 3rd time this week. Unacceptable.",
            "Seriously frustrated with {brand}'s app. So many bugs! 😤",
            "{brand} raised prices AGAIN? Losing a customer. Goodbye.",
            "Why is {brand} so difficult to use? Awful UX design.",
            "{brand} promised X but delivered Y. Total let-down.",
        ],
        "Neutral": [
            "Just saw {brand}'s announcement. Waiting to see how it goes.",
            "{brand} released a new update. Will check it out later.",
            "Interesting move by {brand}. Time will tell.",
            "{brand} earnings report coming out next week.",
            "Reading about {brand}'s new product launch.",
            "Anyone else notice {brand} changed their logo?",
            "{brand} has been in the news a lot lately.",
            "Just switched to {brand}. Still forming an opinion.",
        ],
        "Irrelevant": [
            "Monday mornings are tough. Coffee saves lives. ☕",
            "Can't believe it's already Friday!",
            "This weather is crazy lately.",
            "Just watched an amazing movie last night!",
            "Pizza is the best invention of mankind.",
            "Happy birthday to my best friend! 🎉",
            "The game last night was incredible! What a match.",
            "Working from home has its pros and cons.",
        ],
    }

    rows = []
    for brand, dist in brands.items():
        sentiments = list(dist.keys())
        probs = list(dist.values())
        n = rng.integers(600, 1000)
        chosen = rng.choice(sentiments, size=n, p=probs)
        for sent in chosen:
            tmpl = rng.choice(tweet_templates[sent])
            rows.append({
                "tweet_id": rng.integers(1_000_000, 9_999_999),
                "entity": brand,
                "sentiment": sent,
                "tweet_content": tmpl.replace("{brand}", brand),
            })

    df = pd.DataFrame(rows).sample(frac=1, random_state=42).reset_index(drop=True)
    print(f"✓ Generated {len(df):,} synthetic tweets across {len(brands)} brands.")
    return df


# ════════════════════════════════════════════════════════════════════════════
# 2 ▌ PREPROCESSING
# ════════════════════════════════════════════════════════════════════════════
BASIC_STOPS = {
    "the","a","an","is","it","in","on","at","to","for","of","and","or",
    "but","i","my","me","we","our","you","your","he","she","they","their",
    "this","that","with","from","are","was","be","been","have","has","had",
    "will","would","can","could","do","did","not","no","so","just","also",
    "as","by","up","out","get","got","all","its","im","ive","dont","doesnt",
    "im","rt","via","amp","http","https","www","co","t","s","m","re","ve",
}

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+|#\w+", "", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def tokenize(text: str) -> list[str]:
    return [w for w in text.split() if len(w) > 2 and w not in BASIC_STOPS]

def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = ["tweet_id", "entity", "sentiment", "tweet_content"]
    df.dropna(subset=["sentiment", "tweet_content"], inplace=True)
    df["sentiment"] = df["sentiment"].str.strip().str.title()
    df["entity"]    = df["entity"].str.strip()
    df["clean_text"] = df["tweet_content"].apply(clean_text)
    df["tokens"]     = df["clean_text"].apply(tokenize)
    df["word_count"] = df["tokens"].apply(len)
    df["char_count"] = df["tweet_content"].apply(lambda x: len(str(x)))
    # Simple polarity proxy: +1=Positive, -1=Negative, 0=Neutral/Irrelevant
    pol_map = {"Positive": 1, "Negative": -1, "Neutral": 0, "Irrelevant": 0}
    df["polarity"] = df["sentiment"].map(pol_map)
    return df


# ════════════════════════════════════════════════════════════════════════════
# 3 ▌ VISUALIZATIONS
# ════════════════════════════════════════════════════════════════════════════

def fig1_overview(df):
    """Overall sentiment distribution — donut + bar."""
    counts = df["sentiment"].value_counts()
    colors = [PALETTE.get(s, "#AAA") for s in counts.index]

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.patch.set_facecolor("#0F1117")
    for ax in axes:
        ax.set_facecolor("#0F1117")

    # ── Donut ────────────────────────────────────────────────────────────────
    wedges, texts, autotexts = axes[0].pie(
        counts, labels=counts.index, colors=colors,
        autopct="%1.1f%%", startangle=90,
        wedgeprops=dict(width=0.55, edgecolor="#0F1117", linewidth=2),
        textprops=dict(color="white", fontsize=11),
    )
    for at in autotexts:
        at.set_fontsize(10)
        at.set_fontweight("bold")
        at.set_color("white")
    axes[0].set_title("Overall Sentiment Distribution", color="white",
                      fontsize=15, fontweight="bold", pad=20)

    # ── Bar ──────────────────────────────────────────────────────────────────
    bars = axes[1].bar(counts.index, counts.values, color=colors,
                       edgecolor="#0F1117", linewidth=1.5, width=0.6)
    for bar, val in zip(bars, counts.values):
        axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                     f"{val:,}", ha="center", va="bottom",
                     color="white", fontsize=11, fontweight="bold")
    axes[1].set_title("Tweet Count by Sentiment", color="white",
                      fontsize=15, fontweight="bold")
    axes[1].tick_params(colors="white")
    axes[1].set_xlabel("Sentiment", color="white", fontsize=11)
    axes[1].set_ylabel("Count", color="white", fontsize=11)
    for spine in axes[1].spines.values():
        spine.set_edgecolor("#444")
    axes[1].yaxis.label.set_color("white")

    plt.suptitle("📊  Twitter Sentiment Analysis — Public Opinion Dashboard",
                 color="white", fontsize=17, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig1_overall_sentiment.png", dpi=150, bbox_inches="tight",
                facecolor="#0F1117")
    plt.close()
    print("  ✓ fig1_overall_sentiment.png")


def fig2_brand_breakdown(df):
    """Stacked bar — sentiment per brand."""
    top_brands = df["entity"].value_counts().head(8).index.tolist()
    sub = df[df["entity"].isin(top_brands)]
    pivot = sub.groupby(["entity", "sentiment"]).size().unstack(fill_value=0)
    # ensure all sentiment columns exist
    for s in ["Positive", "Negative", "Neutral", "Irrelevant"]:
        if s not in pivot.columns:
            pivot[s] = 0
    pivot = pivot[["Positive", "Neutral", "Negative", "Irrelevant"]]
    pivot_pct = pivot.div(pivot.sum(axis=1), axis=0) * 100

    fig, ax = plt.subplots(figsize=(14, 7))
    fig.patch.set_facecolor("#0F1117")
    ax.set_facecolor("#0F1117")

    bottoms = np.zeros(len(pivot_pct))
    for sent in pivot_pct.columns:
        bars = ax.bar(pivot_pct.index, pivot_pct[sent],
                      bottom=bottoms, label=sent,
                      color=PALETTE[sent], edgecolor="#0F1117", linewidth=0.8)
        for bar, val in zip(bars, pivot_pct[sent]):
            if val > 6:
                ax.text(bar.get_x() + bar.get_width()/2,
                        bar.get_y() + bar.get_height()/2,
                        f"{val:.1f}%", ha="center", va="center",
                        color="white", fontsize=9, fontweight="bold")
        bottoms += pivot_pct[sent].values

    ax.set_title("Sentiment Breakdown by Brand (% of Tweets)",
                 color="white", fontsize=15, fontweight="bold", pad=15)
    ax.set_ylabel("Percentage (%)", color="white", fontsize=11)
    ax.tick_params(colors="white", labelsize=10)
    for spine in ax.spines.values():
        spine.set_edgecolor("#444")
    leg = ax.legend(loc="upper right", framealpha=0.15,
                    labelcolor="white", fontsize=10)
    leg.get_frame().set_edgecolor("#555")
    plt.tight_layout()
    plt.savefig(f"{OUT}fig2_brand_breakdown.png", dpi=150, bbox_inches="tight",
                facecolor="#0F1117")
    plt.close()
    print("  ✓ fig2_brand_breakdown.png")


def fig3_polarity_heatmap(df):
    """Heatmap of average polarity per brand."""
    top_brands = df["entity"].value_counts().head(8).index.tolist()
    sub = df[df["entity"].isin(top_brands)]
    pol = sub.groupby("entity")["polarity"].agg(["mean", "count"]).reset_index()
    pol.columns = ["Brand", "Avg Polarity", "Count"]
    pol.sort_values("Avg Polarity", ascending=False, inplace=True)

    fig, ax = plt.subplots(figsize=(10, 6))
    fig.patch.set_facecolor("#0F1117")
    ax.set_facecolor("#0F1117")

    cmap = LinearSegmentedColormap.from_list(
        "rg", ["#E74C3C", "#888888", "#2ECC71"], N=256)
    norm_vals = (pol["Avg Polarity"] - pol["Avg Polarity"].min()) / \
                (pol["Avg Polarity"].max() - pol["Avg Polarity"].min() + 1e-9)

    bars = ax.barh(pol["Brand"], pol["Avg Polarity"],
                   color=[cmap(v) for v in norm_vals],
                   edgecolor="#0F1117", linewidth=1)
    ax.axvline(0, color="white", linewidth=0.8, linestyle="--", alpha=0.5)
    for bar, val in zip(bars, pol["Avg Polarity"]):
        ax.text(val + (0.01 if val >= 0 else -0.01),
                bar.get_y() + bar.get_height()/2,
                f"{val:+.3f}", va="center",
                ha="left" if val >= 0 else "right",
                color="white", fontsize=10, fontweight="bold")

    ax.set_title("Average Sentiment Polarity per Brand\n"
                 "(+1 = Fully Positive | −1 = Fully Negative)",
                 color="white", fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel("Average Polarity Score", color="white", fontsize=11)
    ax.tick_params(colors="white", labelsize=10)
    for spine in ax.spines.values():
        spine.set_edgecolor("#444")
    plt.tight_layout()
    plt.savefig(f"{OUT}fig3_polarity_heatmap.png", dpi=150, bbox_inches="tight",
                facecolor="#0F1117")
    plt.close()
    print("  ✓ fig3_polarity_heatmap.png")


def fig4_wordcloud(df):
    """Word clouds for Positive and Negative tweets."""
    if not WC_AVAILABLE:
        print("  ⚠  WordCloud not installed — skipping fig4.")
        return

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    fig.patch.set_facecolor("#0F1117")

    for ax, sentiment, cmap_name in zip(
        axes,
        ["Positive", "Negative"],
        ["Greens", "Reds"]
    ):
        tokens = df[df["sentiment"] == sentiment]["tokens"].explode().dropna()
        freq = Counter(tokens)
        wc = WordCloud(
            width=700, height=450,
            background_color="black",
            colormap=cmap_name,
            max_words=80,
            stopwords=STOPWORDS,
            prefer_horizontal=0.9,
        ).generate_from_frequencies(freq)

        ax.imshow(wc, interpolation="bilinear")
        ax.axis("off")
        ax.set_facecolor("#0F1117")
        ax.set_title(f"🔤  {sentiment} Tweets — Word Cloud",
                     color="white", fontsize=14, fontweight="bold", pad=10)

    plt.suptitle("Top Words in Positive vs Negative Tweets",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig4_wordcloud.png", dpi=150, bbox_inches="tight",
                facecolor="#0F1117")
    plt.close()
    print("  ✓ fig4_wordcloud.png")


def fig5_top_words_bar(df):
    """Top-20 words in Positive and Negative tweets (bar chart fallback)."""
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    fig.patch.set_facecolor("#0F1117")

    for ax, sentiment, color in zip(
        axes, ["Positive", "Negative"], ["#2ECC71", "#E74C3C"]
    ):
        tokens = df[df["sentiment"] == sentiment]["tokens"].explode().dropna()
        top = pd.Series(Counter(tokens)).nlargest(15)

        ax.set_facecolor("#0F1117")
        bars = ax.barh(top.index[::-1], top.values[::-1],
                       color=color, edgecolor="#0F1117", linewidth=0.5)
        for bar, val in zip(bars, top.values[::-1]):
            ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
                    str(val), va="center", color="white", fontsize=9)
        ax.set_title(f"Top Words — {sentiment} Tweets",
                     color="white", fontsize=13, fontweight="bold")
        ax.tick_params(colors="white", labelsize=9)
        for spine in ax.spines.values():
            spine.set_edgecolor("#444")
        ax.set_xlabel("Frequency", color="white", fontsize=10)

    plt.suptitle("Most Frequent Words by Sentiment",
                 color="white", fontsize=15, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{OUT}fig5_top_words.png", dpi=150, bbox_inches="tight",
                facecolor="#0F1117")
    plt.close()
    print("  ✓ fig5_top_words.png")


def fig6_brand_volume(df):
    """Tweet volume + net-sentiment score per brand (dual-axis)."""
    top_brands = df["entity"].value_counts().head(8).index.tolist()
    sub = df[df["entity"].isin(top_brands)]

    vol = sub.groupby("entity").size().reindex(top_brands)
    net = sub.groupby("entity")["polarity"].sum().reindex(top_brands)
    brands = list(top_brands)
    x = np.arange(len(brands))

    fig, ax1 = plt.subplots(figsize=(14, 6))
    fig.patch.set_facecolor("#0F1117")
    ax1.set_facecolor("#0F1117")
    ax2 = ax1.twinx()
    ax2.set_facecolor("#0F1117")

    w = 0.35
    bars1 = ax1.bar(x - w/2, vol.values, width=w,
                    color="#3498DB", alpha=0.85, label="Tweet Volume", edgecolor="#0F1117")
    bars2 = ax2.bar(x + w/2, net.values, width=w,
                    color=[("#2ECC71" if v >= 0 else "#E74C3C") for v in net.values],
                    alpha=0.85, label="Net Sentiment", edgecolor="#0F1117")

    ax1.set_xticks(x)
    ax1.set_xticklabels(brands, color="white", fontsize=10, rotation=20)
    ax1.set_ylabel("Tweet Count", color="#3498DB", fontsize=11)
    ax1.tick_params(axis="y", colors="#3498DB")
    ax2.set_ylabel("Net Sentiment Score", color="#F1C40F", fontsize=11)
    ax2.tick_params(axis="y", colors="#F1C40F")
    ax2.axhline(0, color="white", linewidth=0.8, linestyle="--", alpha=0.5)

    for spine in ax1.spines.values():
        spine.set_edgecolor("#444")
    for spine in ax2.spines.values():
        spine.set_edgecolor("#444")

    lines = [mpatches.Patch(color="#3498DB", label="Tweet Volume"),
             mpatches.Patch(color="#2ECC71", label="Net Sentiment (Pos)"),
             mpatches.Patch(color="#E74C3C", label="Net Sentiment (Neg)")]
    ax1.legend(handles=lines, loc="upper left", framealpha=0.15,
               labelcolor="white", fontsize=9)
    ax1.set_title("Tweet Volume & Net Sentiment Score by Brand",
                  color="white", fontsize=14, fontweight="bold", pad=15)

    plt.tight_layout()
    plt.savefig(f"{OUT}fig6_brand_volume_sentiment.png", dpi=150,
                bbox_inches="tight", facecolor="#0F1117")
    plt.close()
    print("  ✓ fig6_brand_volume_sentiment.png")


def fig7_correlation_heatmap(df):
    """Correlation heatmap between brands' sentiment percentages."""
    top_brands = df["entity"].value_counts().head(8).index.tolist()
    sub = df[df["entity"].isin(top_brands)]
    pivot = sub.groupby(["entity", "sentiment"]).size().unstack(fill_value=0)
    pivot_pct = pivot.div(pivot.sum(axis=1), axis=0) * 100
    corr = pivot_pct.T.corr()

    fig, ax = plt.subplots(figsize=(9, 7))
    fig.patch.set_facecolor("#0F1117")
    ax.set_facecolor("#0F1117")

    mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
    sns.heatmap(
        corr, ax=ax, annot=True, fmt=".2f", cmap="RdYlGn",
        linewidths=0.5, linecolor="#333",
        cbar_kws={"shrink": 0.8},
        annot_kws={"size": 10, "color": "white"},
    )
    ax.set_title("Brand Sentiment Similarity Heatmap\n"
                 "(How similar are brands' sentiment profiles?)",
                 color="white", fontsize=13, fontweight="bold", pad=15)
    ax.tick_params(colors="white", labelsize=9)
    ax.figure.axes[-1].tick_params(colors="white")

    plt.tight_layout()
    plt.savefig(f"{OUT}fig7_brand_correlation.png", dpi=150,
                bbox_inches="tight", facecolor="#0F1117")
    plt.close()
    print("  ✓ fig7_brand_correlation.png")


def fig8_summary_dashboard(df):
    """Mini summary-statistics dashboard."""
    top_brands = df["entity"].value_counts().head(6).index.tolist()
    sub = df[df["entity"].isin(top_brands)]

    pos_rate = sub.groupby("entity").apply(
        lambda x: (x["sentiment"] == "Positive").mean() * 100
    ).reindex(top_brands).sort_values(ascending=False)

    neg_rate = sub.groupby("entity").apply(
        lambda x: (x["sentiment"] == "Negative").mean() * 100
    ).reindex(top_brands)

    wc_avg = sub.groupby("entity")["word_count"].mean().reindex(top_brands)

    fig = plt.figure(figsize=(16, 10))
    fig.patch.set_facecolor("#0F1117")
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.45, wspace=0.3)

    def dark_ax(ax):
        ax.set_facecolor("#1A1D2E")
        ax.tick_params(colors="white")
        for spine in ax.spines.values():
            spine.set_edgecolor("#444")
        return ax

    # KPI row at top
    kpi_ax = fig.add_subplot(gs[0, :])
    kpi_ax.set_facecolor("#0F1117")
    kpi_ax.axis("off")

    total = len(df)
    pos_pct = (df["sentiment"] == "Positive").mean() * 100
    neg_pct = (df["sentiment"] == "Negative").mean() * 100
    neu_pct = (df["sentiment"] == "Neutral").mean() * 100
    brands_n = df["entity"].nunique()

    kpis = [
        ("🐦 Total Tweets",  f"{total:,}",         "#3498DB"),
        ("✅ Positive Rate", f"{pos_pct:.1f}%",    "#2ECC71"),
        ("❌ Negative Rate", f"{neg_pct:.1f}%",    "#E74C3C"),
        ("⚖️  Neutral Rate",  f"{neu_pct:.1f}%",    "#F1C40F"),
        ("🏢 Brands Tracked", f"{brands_n}",        "#9B59B6"),
    ]
    for i, (label, val, col) in enumerate(kpis):
        x = 0.1 + i * 0.19
        kpi_ax.text(x, 0.75, val, transform=kpi_ax.transAxes,
                    fontsize=24, fontweight="bold", color=col, ha="center")
        kpi_ax.text(x, 0.25, label, transform=kpi_ax.transAxes,
                    fontsize=10, color="#AAAAAA", ha="center")

    # Positive Rate
    ax1 = dark_ax(fig.add_subplot(gs[1, 0]))
    colors1 = ["#2ECC71" if v == pos_rate.max() else "#27AE60"
               for v in pos_rate.values]
    ax1.barh(pos_rate.index, pos_rate.values, color=colors1, edgecolor="#0F1117")
    ax1.set_title("Positive Tweet Rate (%)", color="white", fontsize=12, fontweight="bold")
    ax1.set_xlabel("%", color="white")
    ax1.tick_params(colors="white")

    # Negative Rate
    ax2 = dark_ax(fig.add_subplot(gs[1, 1]))
    colors2 = ["#E74C3C" if v == neg_rate.max() else "#C0392B"
               for v in neg_rate.values]
    ax2.barh(neg_rate.reindex(pos_rate.index).index,
             neg_rate.reindex(pos_rate.index).values,
             color=colors2, edgecolor="#0F1117")
    ax2.set_title("Negative Tweet Rate (%)", color="white", fontsize=12, fontweight="bold")
    ax2.set_xlabel("%", color="white")
    ax2.tick_params(colors="white")

    plt.suptitle("📈  Sentiment Analysis — Executive Summary Dashboard",
                 color="white", fontsize=16, fontweight="bold", y=1.01)
    plt.savefig(f"{OUT}fig8_summary_dashboard.png", dpi=150,
                bbox_inches="tight", facecolor="#0F1117")
    plt.close()
    print("  ✓ fig8_summary_dashboard.png")


# ════════════════════════════════════════════════════════════════════════════
# 4 ▌ SUMMARY STATS
# ════════════════════════════════════════════════════════════════════════════
def print_summary(df):
    print("\n" + "═"*60)
    print("  SENTIMENT ANALYSIS — SUMMARY REPORT")
    print("═"*60)
    print(f"  Total tweets analysed : {len(df):,}")
    print(f"  Unique brands/topics  : {df['entity'].nunique()}")
    print(f"\n  ── Sentiment Distribution ──")
    vc = df["sentiment"].value_counts()
    for s, c in vc.items():
        bar = "█" * int(c / len(df) * 40)
        print(f"  {s:<12}: {c:>5,}  {c/len(df)*100:5.1f}%  {bar}")

    print(f"\n  ── Top Brands by Volume ──")
    for brand, cnt in df["entity"].value_counts().head(5).items():
        pos = (df[df["entity"]==brand]["sentiment"]=="Positive").mean()*100
        neg = (df[df["entity"]==brand]["sentiment"]=="Negative").mean()*100
        print(f"  {brand:<12}: {cnt:>5,} tweets | +{pos:.0f}% Pos | -{neg:.0f}% Neg")

    best = df.groupby("entity")["polarity"].mean().idxmax()
    worst = df.groupby("entity")["polarity"].mean().idxmin()
    print(f"\n  🏆  Most Positive Brand : {best}")
    print(f"  ⚠️   Most Negative Brand : {worst}")
    print("═"*60 + "\n")


# ════════════════════════════════════════════════════════════════════════════
# 5 ▌ MAIN
# ════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import os
    os.makedirs(OUT, exist_ok=True)

    print("\n🚀  Prodigy InfoTech — Task 4 | Twitter Sentiment Analysis")
    print("─" * 60)

    df_raw = load_or_generate()
    df     = preprocess(df_raw)

    print_summary(df)

    print("📊  Generating visualizations …")
    fig1_overview(df)
    fig2_brand_breakdown(df)
    fig3_polarity_heatmap(df)
    fig4_wordcloud(df)
    fig5_top_words_bar(df)
    fig6_brand_volume(df)
    fig7_correlation_heatmap(df)
    fig8_summary_dashboard(df)

    print(f"\n✅  All 8 visualizations saved to  {OUT}")
    print("   fig1_overall_sentiment.png")
    print("   fig2_brand_breakdown.png")
    print("   fig3_polarity_heatmap.png")
    print("   fig4_wordcloud.png  (if WordCloud installed)")
    print("   fig5_top_words.png")
    print("   fig6_brand_volume_sentiment.png")
    print("   fig7_brand_correlation.png")
    print("   fig8_summary_dashboard.png")
